package com.hellokoding.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
