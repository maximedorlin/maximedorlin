package com.hellokoding.springboot;

import org.mapstruct.Mapper;

@Mapper
public class LibraryMapper {

}
