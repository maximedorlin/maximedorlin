package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Application;
import com.afreetech.recrutement.model.QuestionResponse;
import com.afreetech.recrutement.model.users.User;
import com.afreetech.recrutement.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

//    @PostMapping
//    public ResponseEntity<Application> applyToJobOffer(@RequestParam Long jobOfferId,
//                                                       @AuthenticationPrincipal User user,
//                                                       @RequestBody(required = false) List<QuestionResponse> responses) {
//        Application application = applicationService.applyToJobOffer(jobOfferId, user, responses);
//        return new ResponseEntity<>(application, HttpStatus.CREATED);
//    }


    @PostMapping
    public ResponseEntity<Application> applyToJobOffer(
            @RequestParam Long jobOfferId,
            @AuthenticationPrincipal User user,
            @RequestBody List<QuestionResponse> responses) { // Attendez une liste directement
        Application application = applicationService.applyToJobOffer(jobOfferId, user, responses);
        return new ResponseEntity<>(application, HttpStatus.CREATED);
    }


    @GetMapping("/user")
    public ResponseEntity<List<Application>> getUserApplications(@AuthenticationPrincipal User user) {
        List<Application> applications = applicationService.getApplicationsByUser(user);
        return ResponseEntity.ok(applications);
    }
}
