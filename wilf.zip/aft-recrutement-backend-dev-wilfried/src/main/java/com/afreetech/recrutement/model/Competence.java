package com.afreetech.recrutement.model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name = "aft_competence")
public class Competence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_competence")
    private Integer idCompetence;

    @Column(name = "titre", nullable = false, length = 100)
    private String titre;

    @Column(name = "description", nullable = false)
    private String description;

    public Competence() {

    }


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_id_domaine_comp", nullable = false)
    private DomaineCompetence domaineCompetence;

//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "id_job", nullable = false)
//    private Job job;


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Integer getIdCompetence() {
        return idCompetence;
    }

    public void setIdCompetence(Integer idCompetence) {
        this.idCompetence = idCompetence;
    }

    public Competence(Integer idCompetence, String description, String titre) {
        this.idCompetence = idCompetence;
        this.description = description;
        this.titre = titre;
    }
}
