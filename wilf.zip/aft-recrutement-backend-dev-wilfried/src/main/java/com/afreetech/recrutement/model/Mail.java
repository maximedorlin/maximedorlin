
package com.afreetech.recrutement.model;

import jakarta.persistence.*;

@Entity
@Table(name = "rct_mail")
public class Mail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_mail")
    private Integer idMail;

    @Column(name = "type_mail", nullable = false, length = 50)
    private String typeMail;

    @Column(name = "description_mail", nullable = false, length = 255)
    private String descriptionMail;

    @Column(name = "contenu_mail", nullable = false, columnDefinition = "TEXT")
    private String contenuMail;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_cand", nullable = false)
    private Postulant postulant;

    
    public Postulant getPostulant() {
        return postulant;
    }
    public void setPostulant(Postulant postulant) {
        this.postulant = postulant;
    }

    public Integer getIdMail() {
        return idMail;
    }

    public void setIdMail(Integer idMail) {
        this.idMail = idMail;
    }

    public String getTypeMail() {
        return typeMail;
    }

    public void setTypeMail(String typeMail) {
        this.typeMail = typeMail;
    }

    public String getDescriptionMail() {
        return descriptionMail;
    }

    public void setDescriptionMail(String descriptionMail) {
        this.descriptionMail = descriptionMail;
    }

    public String getContenuMail() {
        return contenuMail;
    }

    public void setContenuMail(String contenuMail) {
        this.contenuMail = contenuMail;
    }

    public Mail() {
    }
}
