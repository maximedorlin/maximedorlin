package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Evaluation;

import java.util.List;
import java.util.Optional;

public interface EvaluationService {

    Evaluation saveEvaluation(Evaluation evaluation);

    Optional<Evaluation> getEvaluationById(Long idEvaluation);

    List<Evaluation> getAllEvaluations();

    void deleteEvaluation(Long idEvaluation);

    Evaluation updateEvaluation(Long idEvaluation, Evaluation evaluation);
}
