package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Postulant;
import com.afreetech.recrutement.repository.PostulantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PostulantServiceImpl implements PostulantService {

    @Autowired
    private PostulantRepository postulantRepository;

    @Override
    public Postulant savePostulant(Postulant postulant) {
        return postulantRepository.save(postulant);
    }

    @Override
    public Optional<Postulant> getPostulantById(Integer idCand) {
        return postulantRepository.findById(idCand);
    }

    @Override
    public List<Postulant> getAllPostulants() {
        return postulantRepository.findAll();
    }

    @Override
    public void deletePostulant(Integer idCand) {
        postulantRepository.deleteById(idCand);
    }

    @Override
    public Postulant updatePostulant(Integer idCand, Postulant postulant) {
        Postulant postulantToUpdate = postulantRepository.findById(idCand)
                .orElseThrow(() -> new RuntimeException("Postulant not found with id " + idCand));

        postulantToUpdate.setNiveauEtude(postulant.getNiveauEtude());
        postulantToUpdate.setAnneeExperience(postulant.getAnneeExperience());
        postulantToUpdate.setDernierEtablissement(postulant.getDernierEtablissement());
        postulantToUpdate.setDispoDu(postulant.getDispoDu());
        postulantToUpdate.setDispoAu(postulant.getDispoAu());
        postulantToUpdate.setModalite(postulant.getModalite());
        postulantToUpdate.setPermisConduire(postulant.getPermisConduire());
        postulantToUpdate.setSituationCand(postulant.getSituationCand());
        postulantToUpdate.setMotivation(postulant.getMotivation());
        postulantToUpdate.setPostulerList(postulant.getPostulerList());
        postulantToUpdate.setEvaluationList(postulant.getEvaluationList());

        return postulantRepository.save(postulantToUpdate);
    }
}
