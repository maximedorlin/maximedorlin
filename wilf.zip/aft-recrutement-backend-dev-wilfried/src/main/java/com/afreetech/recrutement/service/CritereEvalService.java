package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.CritereEval;
import java.util.List;
import java.util.Optional;

public interface CritereEvalService {

    CritereEval saveCritereEval(CritereEval critereEval);

    Optional<CritereEval> getCritereEvalById(Integer idCritereEval);

    List<CritereEval> getAllCritereEvals();

    void deleteCritereEval(Integer idCritereEval);

    CritereEval updateCritereEval(Integer idCritereEval, CritereEval critereEval);

    List<CritereEval> getAllCritereEval();
}
