package com.afreetech.recrutement.model.users.dtos;

public record AuthenticationDTO(String email, String password) {
}
