package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.CritereEval;
import com.afreetech.recrutement.service.CritereEvalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/critere-eval")
public class CritereEvalController {

    @Autowired
    private CritereEvalService critereEvalService;

    @PostMapping
    public ResponseEntity<CritereEval> createCritereEval(@RequestBody CritereEval critereEval) {
        CritereEval savedCritereEval = critereEvalService.saveCritereEval(critereEval);
        return new ResponseEntity<>(savedCritereEval, HttpStatus.CREATED);
    }

    @GetMapping("/{idCritereEval}")
    public ResponseEntity<CritereEval> getCritereEvalById(@PathVariable Integer idCritereEval) {
        Optional<CritereEval> critereEval = critereEvalService.getCritereEvalById(idCritereEval);
        return critereEval.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<CritereEval>> getAllCritereEval() {
        List<CritereEval> critereEvalList = critereEvalService.getAllCritereEval();
        return ResponseEntity.ok(critereEvalList);
    }

    @DeleteMapping("/{idCritereEval}")
    public ResponseEntity<Void> deleteCritereEval(@PathVariable Integer idCritereEval) {
        critereEvalService.deleteCritereEval(idCritereEval);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{idCritereEval}")
    public ResponseEntity<CritereEval> updateCritereEval(@PathVariable Integer idCritereEval, @RequestBody CritereEval critereEval) {
        if (!critereEvalService.getCritereEvalById(idCritereEval).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        critereEval.setIdCritereEval(idCritereEval);
        CritereEval updatedCritereEval = critereEvalService.updateCritereEval(idCritereEval, critereEval);
        return ResponseEntity.ok(updatedCritereEval);
    }
}
