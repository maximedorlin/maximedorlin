package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Competence;

import java.util.List;
import java.util.Optional;

public interface CompetenceService {

    Competence saveCompetence(Competence competence);

    Optional<Competence> getCompetenceById(Integer idCompetence);

    List<Competence> getAllCompetences();

    void deleteCompetence(Integer idCompetence);

    Competence updateCompetence(Integer idCompetence, Competence competence);


}
