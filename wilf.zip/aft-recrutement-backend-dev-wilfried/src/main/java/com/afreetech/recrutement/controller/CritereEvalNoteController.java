package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.CritereEvalNote;
import com.afreetech.recrutement.service.CritereEvalNoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/critere-eval-notes")
public class CritereEvalNoteController {

    @Autowired
    private CritereEvalNoteService critereEvalNoteService;

    @GetMapping
    public ResponseEntity<List<CritereEvalNote>> getAllCritereEvalNotes() {
        List<CritereEvalNote> critereEvalNotes = critereEvalNoteService.getAllCritereEvalNotes();
        return new ResponseEntity<>(critereEvalNotes, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CritereEvalNote> getCritereEvalNoteById(@PathVariable Long id) {
        Optional<CritereEvalNote> critereEvalNote = critereEvalNoteService.getCritereEvalNoteById(id);
        return critereEvalNote.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<CritereEvalNote> createCritereEvalNote(@RequestBody CritereEvalNote critereEvalNote) {
        CritereEvalNote savedCritereEvalNote = critereEvalNoteService.saveCritereEvalNote(critereEvalNote);
        return new ResponseEntity<>(savedCritereEvalNote, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CritereEvalNote> updateCritereEvalNote(@PathVariable Long id, @RequestBody CritereEvalNote critereEvalNote) {
        if (!critereEvalNoteService.getCritereEvalNoteById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        critereEvalNote.setIdCritereEvalNote(id); // Assurez-vous que l'ID est mis à jour
        CritereEvalNote updatedCritereEvalNote = critereEvalNoteService.updateCritereEvalNote(id, critereEvalNote);
        return new ResponseEntity<>(updatedCritereEvalNote, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCritereEvalNote(@PathVariable Long id) {
        if (!critereEvalNoteService.getCritereEvalNoteById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        critereEvalNoteService.deleteCritereEvalNote(id);
        return ResponseEntity.noContent().build();
    }
}
