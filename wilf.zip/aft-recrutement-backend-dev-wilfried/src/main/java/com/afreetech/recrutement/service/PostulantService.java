package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Postulant;

import java.util.List;
import java.util.Optional;

public interface PostulantService {

    Postulant savePostulant(Postulant postulant);

    Optional<Postulant> getPostulantById(Integer idCand);

    List<Postulant> getAllPostulants();

    void deletePostulant(Integer idCand);

    Postulant updatePostulant(Integer idCand, Postulant postulant);
}
