package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Sondage;
import com.afreetech.recrutement.repository.SondageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SondageServiceImpl implements SondageService {

    private final SondageRepository sondageRepository;

    @Autowired
    public SondageServiceImpl(SondageRepository sondageRepository) {
        this.sondageRepository = sondageRepository;
    }

    @Override
    public Sondage saveSondage(Sondage sondage) {
        return sondageRepository.save(sondage);
    }

    @Override
    public Optional<Sondage> getSondageById(Integer id) {
        return sondageRepository.findById(id);
    }

    @Override
    public List<Sondage> getAllSondages() {
        return sondageRepository.findAll();
    }

    @Override
    public void deleteSondage(Integer id) {
        sondageRepository.deleteById(id);
    }

    @Override
    public Sondage updateSondage(Integer idSondage, Sondage sondage) {
        // Trouver l'entité existante par ID
        Sondage sondageToUpdate = sondageRepository.findById(idSondage)
                .orElseThrow(() -> new RuntimeException("Sondage not found with id " + idSondage));

        // Mettre à jour les attributs de l'entité trouvée
        sondageToUpdate.setTitre(sondage.getTitre());
        sondageToUpdate.setQuetion(sondage.getQuetion());
        sondageToUpdate.setReponce(sondage.getReponce());

        // Sauvegarder les modifications
        return sondageRepository.save(sondageToUpdate);
    }
}
