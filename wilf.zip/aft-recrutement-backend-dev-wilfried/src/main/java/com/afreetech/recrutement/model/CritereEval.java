package com.afreetech.recrutement.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "rct_critere_eval")
public class CritereEval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_critere_eval")
    private Integer idCritereEval;

    @Column(name = "type_critere", nullable = false)
    private Integer typeCritere;

    @Column(name = "nom_critere_eval", nullable = false, length = 100)
    private String nomCritereEval;


    @OneToMany (mappedBy = "critereEval", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CritereEvalNote> critereEvalNoteList;


    public Integer getIdCritereEval() {
        return idCritereEval;
    }

    public void setIdCritereEval(Integer idCritereEval) {
        this.idCritereEval = idCritereEval;
    }

    public Integer getTypeCritere() {
        return typeCritere;
    }

    public void setTypeCritere(Integer typeCritere) {
        this.typeCritere = typeCritere;
    }

    public String getNomCritereEval() {
        return nomCritereEval;
    }

    public void setNomCritereEval(String nomCritereEval) {
        this.nomCritereEval = nomCritereEval;
    }

    public List<CritereEvalNote> getCritereEvalNoteList() {
        return critereEvalNoteList;
    }

    public void setCritereEvalNoteList(List<CritereEvalNote> critereEvalNoteList) {
        this.critereEvalNoteList = critereEvalNoteList;
    }

    public CritereEval() {
    }
}
