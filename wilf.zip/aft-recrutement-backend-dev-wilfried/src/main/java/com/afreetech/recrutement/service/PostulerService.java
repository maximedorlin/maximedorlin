package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Postuler;
import java.util.List;
import java.util.Optional;

public interface PostulerService {
    Postuler savePostuler(Postuler postuler);
    Optional<Postuler> getPostulerById(Integer idPostuler);
    List<Postuler> getAllPostulers();
    void deletePostuler(Integer idPostuler);
    Postuler updatePostuler(Integer idPostuler, Postuler postuler);
}
