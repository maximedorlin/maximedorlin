package com.afreetech.recrutement.model;

import com.afreetech.recrutement.model.users.User;
import jakarta.persistence.*;
import lombok.Data;



import java.util.List;

@Entity
@Data
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private JobOffer jobOffer;

    @ManyToOne
    private User user;

    private Double score; // Score du questionnaire, si applicable



    @Lob
    private String cv; // CV en Base64 (obligatoire)

    @ElementCollection
//    @Lob
    @CollectionTable(name = "application_diplomas", joinColumns = @JoinColumn(name = "application_id"))

    private List<String> diplomas; // Liste de diplômes en Base64 (obligatoire)

    @ElementCollection
    @CollectionTable(name = "application_certifications", joinColumns = @JoinColumn(name = "application_id"))

    private List<String> certifications; // Liste de certifications en Base64 (facultatif)

    @ElementCollection
    @CollectionTable(name = "application_other_documents", joinColumns = @JoinColumn(name = "application_id"))

    private List<String> otherDocuments; // Autres documents en Base64 (facultatif)




    @OneToMany(mappedBy = "application", cascade = CascadeType.ALL) // Assurez-vous d'utiliser CascadeType.ALL
    private List<QuestionResponse> questionResponses; // Réponses aux questions
}