package com.afreetech.recrutement.model;

import com.afreetech.recrutement.model.users.User;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private JobOffer jobOffer;

    @ManyToOne
    private User user;

    private Double score; // Score du questionnaire, si applicable


    @OneToMany(mappedBy = "application", cascade = CascadeType.ALL) // Assurez-vous d'utiliser CascadeType.ALL
    private List<QuestionResponse> questionResponses; // Réponses aux questions
}