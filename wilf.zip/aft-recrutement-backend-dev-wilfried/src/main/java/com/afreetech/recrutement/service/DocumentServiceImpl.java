package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Document;
import com.afreetech.recrutement.repository.DocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    private DocumentRepository documentRepository;

    @Override
    public Document saveDocument(Document document) {
        return documentRepository.save(document);
    }

    @Override
    public Optional<Document> getDocumentById(Integer idDocument) {
        return documentRepository.findById(idDocument);
    }

    @Override
    public List<Document> getAllDocuments() {
        return documentRepository.findAll();
    }

    @Override
    public void deleteDocument(Integer idDocument) {
        documentRepository.deleteById(idDocument);
    }

    @Override
    public Document updateDocument(Integer idDocument, Document document) {
        Document documentToUpdate = documentRepository.findById(idDocument)
                .orElseThrow(() -> new RuntimeException("Document not found with id " + idDocument));

        documentToUpdate.setAnneeObtention(document.getAnneeObtention());
        documentToUpdate.setTitreDoc(document.getTitreDoc());
        documentToUpdate.setEtablissementObtention(document.getEtablissementObtention());
        documentToUpdate.setMention(document.getMention());
        documentToUpdate.setType(document.getType());
        documentToUpdate.setDocCourant(document.getDocCourant());
       // documentToUpdate.setPostuler(document.getPostuler());

        return documentRepository.save(documentToUpdate);
    }
}
