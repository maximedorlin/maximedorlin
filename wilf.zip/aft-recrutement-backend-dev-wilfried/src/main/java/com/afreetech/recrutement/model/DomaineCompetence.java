package com.afreetech.recrutement.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "rct_domaine_competence")
public class DomaineCompetence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_domaine_comp", nullable = false)
    private Integer idDomaineComp;

    @Column(name = "nom_domaine_comp", nullable = false, length = 200)
    private String nomDomaineComp;


    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "fk_id_domaine_comp",referencedColumnName = "id_domaine_comp")
    private List<Competence> competencesList;


    public Integer getIdDomaineComp() {
        return idDomaineComp;
    }

    public void setIdDomaineComp(Integer idDomaineComp) {
        this.idDomaineComp = idDomaineComp;
    }

    public String getNomDomaineComp() {
        return nomDomaineComp;
    }

    public void setNomDomaineComp(String nomDomaineComp) {
        this.nomDomaineComp = nomDomaineComp;
    }

    public  List<Competence> getCompetencesList() {
        return competencesList;
    }
//
    public void setCompetencesList(List<Competence> competencesList) {
        this.competencesList = competencesList;
    }

    public DomaineCompetence() {
    }


    public void setCompetencesList(Optional<Competence> competence) {
    }
}
