package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Application;
import com.afreetech.recrutement.model.QuestionResponse;
import com.afreetech.recrutement.model.users.User;

import java.util.List;

public interface ApplicationService {
//    Application applyToJobOffer(Long jobOfferId, User user, List<QuestionResponse> responses);
Application applyToJobOffer(Long jobOfferId,
                            User user,
                            List<QuestionResponse> responses,
                            String cv,
                            List<String> diplomas,
                            List<String> certifications,
                            List<String> otherDocuments);
    List<Application> getApplicationsByUser(User user);
}