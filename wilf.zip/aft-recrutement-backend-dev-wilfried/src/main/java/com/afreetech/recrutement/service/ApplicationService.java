package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Application;
import com.afreetech.recrutement.model.QuestionResponse;
import com.afreetech.recrutement.model.users.User;

import java.util.List;

public interface ApplicationService {
    Application applyToJobOffer(Long jobOfferId, User user, List<QuestionResponse> responses);
    List<Application> getApplicationsByUser(User user);
}