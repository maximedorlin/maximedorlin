package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Sondage;

import java.util.List;
import java.util.Optional;

public interface SondageService {
    Sondage saveSondage(Sondage sondage);
    Optional<Sondage> getSondageById(Integer id);
    List<Sondage> getAllSondages();
    void deleteSondage(Integer id);
    Sondage updateSondage(Integer id, Sondage sondage);
}
