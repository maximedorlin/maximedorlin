package com.afreetech.recrutement.model;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "rct_critere_eval_note")
public class CritereEvalNote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_critere_eval_note")
    private Long idCritereEvalNote;

    @Column(name = "note", nullable = false)
    private Integer note;

    @Column(name = "date_evaluation", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date dateEvaluation;

    @Column(name = "commentaire", nullable = false, columnDefinition = "TEXT")
    private String commentaire;


    public Evaluation getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(Evaluation evaluation) {
        this.evaluation = evaluation;
    }

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_critere_eval", nullable = false)
    private CritereEval critereEval;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_evaluation", nullable = false)
    private Evaluation evaluation;


    public Long getIdCritereEvalNote() {
        return idCritereEvalNote;
    }

    public void setIdCritereEvalNote(Long idCritereEvalNote) {
        this.idCritereEvalNote = idCritereEvalNote;
    }

    public Integer getNote() {
        return note;
    }

    public void setNote(Integer note) {
        this.note = note;
    }

    public Date getDateEvaluation() {
        return dateEvaluation;
    }

    public void setDateEvaluation(Date dateEvaluation) {
        this.dateEvaluation = dateEvaluation;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public CritereEval getCritereEval() {
        return critereEval;
    }

    public void setCritereEval(CritereEval critereEval) {
        this.critereEval = critereEval;
    }

    public CritereEvalNote() {
    }
}
