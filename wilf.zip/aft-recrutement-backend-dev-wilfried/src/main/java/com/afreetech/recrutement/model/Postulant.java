package com.afreetech.recrutement.model;


import jakarta.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "rct_postulant")
public class Postulant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cand")
    private Integer idCand;

    @Column(name = "niveau_etude", nullable = false)
    private Integer niveauEtude;

    @Column(name = "annee_experience", nullable = false)
    @Temporal(TemporalType.DATE)
    private Integer anneeExperience;

    @Column(name = "dernier_etablissement", nullable = false, length = 200)
    private String dernierEtablissement;

    @Column(name = "dispo_du")
    @Temporal(TemporalType.DATE)
    private Date dispoDu;

    @Column(name = "dispo_au")
    @Temporal(TemporalType.DATE)
    private Date dispoAu;

    @Column(name = "modilite", nullable = false, length = 100)
    private String modalite;

    @Column(name = "permis_conduire", nullable = false)
    private Boolean permisConduire;

    @Column(name = "situation_cand", nullable = false, length = 100)
    private String situationCand;

    @Column(name = "motivation", nullable = false, columnDefinition = "TEXT")
    private String motivation;


    @OneToMany (mappedBy = "postulant", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Postuler> postulerList;

    @OneToMany (mappedBy = "postulant", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Evaluation> evaluationList;

    @OneToMany(mappedBy = "postulant", cascade = CascadeType.ALL, orphanRemoval = true)
        private List<Mail> mailList;


    public Integer getIdCand() {
        return idCand;
    }

    public void setIdCand(Integer idCand) {
        this.idCand = idCand;
    }

    public Integer getNiveauEtude() {
        return niveauEtude;
    }

    public void setNiveauEtude(Integer niveauEtude) {
        this.niveauEtude = niveauEtude;
    }

    public Integer getAnneeExperience() {
        return anneeExperience;
    }

    public void setAnneeExperience(Integer anneeExperience) {
        this.anneeExperience = anneeExperience;
    }

    public String getDernierEtablissement() {
        return dernierEtablissement;
    }

    public void setDernierEtablissement(String dernierEtablissement) {
        this.dernierEtablissement = dernierEtablissement;
    }

    public Date getDispoDu() {
        return dispoDu;
    }

    public void setDispoDu(Date dispoDu) {
        this.dispoDu = dispoDu;
    }

    public Date getDispoAu() {
        return dispoAu;
    }

    public void setDispoAu(Date dispoAu) {
        this.dispoAu = dispoAu;
    }

    public String getModalite() {
        return modalite;
    }

    public void setModalite(String modalite) {
        this.modalite = modalite;
    }

    public Boolean getPermisConduire() {
        return permisConduire;
    }

    public void setPermisConduire(Boolean permisConduire) {
        this.permisConduire = permisConduire;
    }

    public String getSituationCand() {
        return situationCand;
    }

    public void setSituationCand(String situationCand) {
        this.situationCand = situationCand;
    }

    public String getMotivation() {
        return motivation;
    }

    public void setMotivation(String motivation) {
        this.motivation = motivation;
    }

    public List<Postuler> getPostulerList() {
        return postulerList;
    }

    public void setPostulerList(List<Postuler> postulerList) {
        this.postulerList = postulerList;
    }

    public List<Evaluation> getEvaluationList() {
        return evaluationList;
    }

    public void setEvaluationList(List<Evaluation> evaluationList) {
        this.evaluationList = evaluationList;
    }

    public Postulant() {
    }
}
