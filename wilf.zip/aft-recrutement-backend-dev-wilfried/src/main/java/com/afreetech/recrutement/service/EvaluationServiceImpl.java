package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Evaluation;
import com.afreetech.recrutement.repository.EvaluationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EvaluationServiceImpl implements EvaluationService {

    @Autowired
    private EvaluationRepository evaluationRepository;

    @Override
    public Evaluation saveEvaluation(Evaluation evaluation) {
        return evaluationRepository.save(evaluation);
    }

    @Override
    public Optional<Evaluation> getEvaluationById(Long idEvaluation) {
        return evaluationRepository.findById(idEvaluation);
    }

    @Override
    public List<Evaluation> getAllEvaluations() {
        return evaluationRepository.findAll();
    }

    @Override
    public void deleteEvaluation(Long idEvaluation) {
        evaluationRepository.deleteById(idEvaluation);
    }

    @Override
    public Evaluation updateEvaluation(Long idEvaluation, Evaluation evaluation) {
        Evaluation evaluationToUpdate = evaluationRepository.findById(idEvaluation)
                .orElseThrow(() -> new RuntimeException("Evaluation not found with id " + idEvaluation));

        evaluationToUpdate.setTitre(evaluation.getTitre());
        evaluationToUpdate.setDateEvaluation(evaluation.getDateEvaluation());
        evaluationToUpdate.setDecisionEvaluation(evaluation.getDecisionEvaluation());
        evaluationToUpdate.setUser(evaluation.getUser());
        evaluationToUpdate.setPostulant(evaluation.getPostulant());

        return evaluationRepository.save(evaluationToUpdate);
    }
}
