package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Competence;
import com.afreetech.recrutement.repository.CompetenceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompetenceServiceImpl implements CompetenceService {

    @Autowired
    private CompetenceRepository competenceRepository;

    @Override
    public Competence saveCompetence(Competence competence) {
        return competenceRepository.save(competence);
    }

    @Override
    public Optional<Competence> getCompetenceById(Integer idCompetence) {
        return competenceRepository.findById(idCompetence);
    }

    @Override
    public List<Competence> getAllCompetences() {
        return competenceRepository.findAll();
    }

    @Override
    public void deleteCompetence(Integer idCompetence) {
        competenceRepository.deleteById(idCompetence);
    }

    @Override
    public Competence updateCompetence(Integer idCompetence, Competence competence) {
        Competence existingCompetence = competenceRepository.findById(idCompetence)
                .orElseThrow(() -> new RuntimeException("Competence not found with id " + idCompetence));

        existingCompetence.setTitre(competence.getTitre());
        existingCompetence.setDescription(competence.getDescription());

        return competenceRepository.save(existingCompetence);
    }
}
