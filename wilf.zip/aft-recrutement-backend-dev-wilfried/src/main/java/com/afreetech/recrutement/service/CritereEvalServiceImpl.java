package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.CritereEval;
import com.afreetech.recrutement.repository.CritereEvalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CritereEvalServiceImpl implements CritereEvalService {

    @Autowired
    private CritereEvalRepository critereEvalRepository;

    @Override
    public CritereEval saveCritereEval(CritereEval critereEval) {
        return critereEvalRepository.save(critereEval);
    }

    @Override
    public Optional<CritereEval> getCritereEvalById(Integer idCritereEval) {
        return critereEvalRepository.findById(idCritereEval);
    }

    @Override
    public List<CritereEval> getAllCritereEvals() {
        return critereEvalRepository.findAll();
    }

    @Override
    public void deleteCritereEval(Integer idCritereEval) {
        critereEvalRepository.deleteById(idCritereEval);
    }

    @Override
    public CritereEval updateCritereEval(Integer idCritereEval, CritereEval critereEval) {
        // Trouver l'entité existante par ID
        CritereEval critereEvalToUpdate = critereEvalRepository.findById(idCritereEval)
                .orElseThrow(() -> new RuntimeException("CritereEval not found with id " + idCritereEval));

        // Mettre à jour les attributs de l'entité trouvée
        critereEvalToUpdate.setTypeCritere(critereEval.getTypeCritere());
        critereEvalToUpdate.setNomCritereEval(critereEval.getNomCritereEval());
        critereEvalToUpdate.setCritereEvalNoteList(critereEval.getCritereEvalNoteList());

        // Sauvegarder les modifications
        return critereEvalRepository.save(critereEvalToUpdate);
    }

    @Override
    public List<CritereEval> getAllCritereEval() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllCritereEval'");
    }
}
