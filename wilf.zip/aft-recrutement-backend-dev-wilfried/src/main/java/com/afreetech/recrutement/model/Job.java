
package com.afreetech.recrutement.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "rct_job")
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_job")
    private Integer idJop;

    @Column(name = "titre_job", nullable = false, length = 200)
    private String titreJob;

    @Column(name = "date_post", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date datePost;

    @Column(name = "fichier_annonce", length = 100)
    private String fichierAnnonce;

    @Column(name = "annonce", nullable = false, columnDefinition = "TEXT")
    private String annonce;

    @Column(name = "statut")
    private Boolean statut;

    @Column(name = "type_contrat")
    private String typeContrat;

    @Column(name = "date_limite")
    @Temporal(TemporalType.DATE)
    private Date dateLimite;


    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Postuler> postulerList = new ArrayList<>();

//    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<Competence> competenceList = new ArrayList<>();


    public String getTitreJob() {
        return titreJob;
    }

    public void setTitreJob(String titreJob) {
        this.titreJob = titreJob;
    }

    public Integer getIdJop() {
        return idJop;
    }

    public void setIdJop(Integer idJop) {
        this.idJop = idJop;
    }

    public Date getDatePost() {
        return datePost;
    }

    public void setDatePost(Date datePost) {
        this.datePost = datePost;
    }

    public String getFichierAnnonce() {
        return fichierAnnonce;
    }

    public void setFichierAnnonce(String fichierAnnonce) {
        this.fichierAnnonce = fichierAnnonce;
    }

    public String getAnnonce() {
        return annonce;
    }

    public void setAnnonce(String annonce) {
        this.annonce = annonce;
    }

    public Boolean getStatut() {
        return statut;
    }

    public void setStatut(Boolean statut) {
        this.statut = statut;
    }

    public String getTypeContrat() {
        return typeContrat;
    }

    public void setTypeContrat(String typeContrat) {
        this.typeContrat = typeContrat;
    }

    public Date getdateLimite() {
        return dateLimite;
    }

    public void setDateLimite(Date dateLimite) {
        this.dateLimite = dateLimite;
    }

    public List<Postuler> getPostulerList() {
        return postulerList;
    }

    public void setPostulerList(List<Postuler> postulerList) {
        this.postulerList = postulerList;
    }

    public Job() {
    }
}
