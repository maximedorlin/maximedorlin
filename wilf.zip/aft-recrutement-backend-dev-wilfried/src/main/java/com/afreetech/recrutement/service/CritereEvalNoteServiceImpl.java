package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.CritereEvalNote;
import com.afreetech.recrutement.repository.CritereEvalNoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CritereEvalNoteServiceImpl implements CritereEvalNoteService {

    @Autowired
    private CritereEvalNoteRepository critereEvalNoteRepository;

    @Override
    public CritereEvalNote saveCritereEvalNote(CritereEvalNote critereEvalNote) {
        return critereEvalNoteRepository.save(critereEvalNote);
    }

    @Override
    public Optional<CritereEvalNote> getCritereEvalNoteById(Long idCritereEvalNote) {
        return critereEvalNoteRepository.findById(idCritereEvalNote);
    }

    @Override
    public List<CritereEvalNote> getAllCritereEvalNotes() {
        return critereEvalNoteRepository.findAll();
    }

    @Override
    public void deleteCritereEvalNote(Long idCritereEvalNote) {
        critereEvalNoteRepository.deleteById(idCritereEvalNote);
    }

    @Override
    public CritereEvalNote updateCritereEvalNote(Long idCritereEvalNote, CritereEvalNote critereEvalNote) {
        // Trouver l'entité existante par ID
        CritereEvalNote critereEvalNoteToUpdate = critereEvalNoteRepository.findById(idCritereEvalNote)
                .orElseThrow(() -> new RuntimeException("CritereEvalNote not found with id " + idCritereEvalNote));

        // Mettre à jour les attributs de l'entité trouvée
        critereEvalNoteToUpdate.setNote(critereEvalNote.getNote());
        critereEvalNoteToUpdate.setDateEvaluation(critereEvalNote.getDateEvaluation());
        critereEvalNoteToUpdate.setCommentaire(critereEvalNote.getCommentaire());
        critereEvalNoteToUpdate.setCritereEval(critereEvalNote.getCritereEval());
        critereEvalNoteToUpdate.setCommentaire(critereEvalNote.getCommentaire());
        critereEvalNoteToUpdate.setCritereEval(critereEvalNote.getCritereEval());

        // Sauvegarder les modifications
        return critereEvalNoteRepository.save(critereEvalNoteToUpdate);
    }
}
