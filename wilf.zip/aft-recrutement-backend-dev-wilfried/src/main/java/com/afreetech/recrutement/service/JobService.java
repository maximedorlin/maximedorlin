package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Job;

import java.util.List;
import java.util.Optional;

public interface JobService {

    Job saveJob(Job job);

    Optional<Job> getJobById(Integer idJob);

    List<Job> getAllJobs();

    void deleteJob(Integer idJob);

    Job updateJob(Integer idJob, Job job);
}
