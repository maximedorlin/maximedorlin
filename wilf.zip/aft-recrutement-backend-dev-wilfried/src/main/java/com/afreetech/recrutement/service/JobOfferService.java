package com.afreetech.recrutement.service;



import com.afreetech.recrutement.model.JobOffer;

import java.util.List;

public interface JobOfferService {
    JobOffer createJobOffer(JobOffer jobOffer);
    List<JobOffer> getAllJobOffers();
    JobOffer getJobOfferById(Long id);
    void deleteJobOffer(Long id);
}
