package com.afreetech.recrutement.repository;

import com.afreetech.recrutement.model.Sondage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SondageRepository extends JpaRepository<Sondage, Integer> {
    // Tu peux ajouter des méthodes de recherche personnalisées si nécessaire
}
