package com.afreetech.recrutement.model.users.dtos;

public record ForgotPasswordDTO(String email) {
}
