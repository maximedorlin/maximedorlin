package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Postuler;
import com.afreetech.recrutement.service.PostulerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/postulers")
public class PostulerController {

    @Autowired
    private PostulerService postulerService;

    @GetMapping
    public ResponseEntity<List<Postuler>> getAllPostulers() {
        List<Postuler> postulers = postulerService.getAllPostulers();
        return new ResponseEntity<>(postulers, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Postuler> getPostulerById(@PathVariable("id") Integer idPostuler) {
        Optional<Postuler> postuler = postulerService.getPostulerById(idPostuler);
        return postuler.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Postuler> createPostuler(@RequestBody Postuler postuler) {
        Postuler savedPostuler = postulerService.savePostuler(postuler);
        return new ResponseEntity<>(savedPostuler, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Postuler> updatePostuler(@PathVariable("id") Integer idPostuler, @RequestBody Postuler postuler) {
        if (!postulerService.getPostulerById(idPostuler).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        postuler.setIdPostuler(idPostuler); // Assurez-vous que l'ID est mis à jour
        Postuler updatedPostuler = postulerService.updatePostuler(idPostuler, postuler);
        return new ResponseEntity<>(updatedPostuler, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePostuler(@PathVariable("id") Integer idPostuler) {
        if (!postulerService.getPostulerById(idPostuler).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        postulerService.deletePostuler(idPostuler);
        return ResponseEntity.noContent().build();
    }
}
