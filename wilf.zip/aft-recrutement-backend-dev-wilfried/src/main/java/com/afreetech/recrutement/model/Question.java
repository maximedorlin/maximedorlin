package com.afreetech.recrutement.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "question")
@Data
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String texte;
    private String choix; // Peut être un JSON ou une liste de choix
    private String reponseCorrecte;
}