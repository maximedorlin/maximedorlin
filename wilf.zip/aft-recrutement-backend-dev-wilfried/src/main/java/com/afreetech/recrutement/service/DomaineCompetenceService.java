package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Competence;
import com.afreetech.recrutement.model.DomaineCompetence;

import java.util.List;
import java.util.Optional;

public interface DomaineCompetenceService {

    DomaineCompetence saveDomaineCompetence(DomaineCompetence domaineCompetence);

    Optional<DomaineCompetence> getDomaineCompetenceById(Integer idDomaineComp);

    List<DomaineCompetence> getAllDomaineCompetences();

    // List<Competence> getAllCompetences();

    void deleteDomaineCompetence(Integer idDomaineComp);

    List<DomaineCompetence> saveAll(List<DomaineCompetence> domaines);

    DomaineCompetence updateDomaineCompetence(Integer idDomaineComp, DomaineCompetence domaineCompetence);
}
