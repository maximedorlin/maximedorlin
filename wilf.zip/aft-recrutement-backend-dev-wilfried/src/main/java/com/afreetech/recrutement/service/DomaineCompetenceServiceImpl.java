package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Competence;
import com.afreetech.recrutement.model.DomaineCompetence;
import com.afreetech.recrutement.repository.DomaineCompetenceRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;

@Service
public class DomaineCompetenceServiceImpl implements DomaineCompetenceService {

    @Autowired
    private DomaineCompetenceRepository domaineCompetenceRepository;

    @Override
    public DomaineCompetence saveDomaineCompetence(DomaineCompetence domaineCompetence) {
        return domaineCompetenceRepository.save(domaineCompetence);
    }

    @Override
    public Optional<DomaineCompetence> getDomaineCompetenceById(Integer idDomaineComp) {
        return domaineCompetenceRepository.findById(idDomaineComp);
    }

    @Override
    public List<DomaineCompetence> getAllDomaineCompetences() {
        return domaineCompetenceRepository.findAll();
    }

    // @Override
    // public List<Competence> getAllCompetences() {
    //     List<Competence> competences = new ArrayList<>();
    //     return competences;
    // }

    @Override
    public void deleteDomaineCompetence(Integer idDomaineComp) {
        domaineCompetenceRepository.deleteById(idDomaineComp);
    }

    @Override
    public List<DomaineCompetence> saveAll(List<DomaineCompetence> domaines) {
        return List.of();
    }

    @Override
    public DomaineCompetence updateDomaineCompetence(Integer idDomaineComp, DomaineCompetence domaineCompetence) {
        DomaineCompetence domaineCompetenceToUpdate = domaineCompetenceRepository.findById(idDomaineComp)
                .orElseThrow(() -> new RuntimeException("DomaineCompetence not found with id " + idDomaineComp));

        domaineCompetenceToUpdate.setNomDomaineComp(domaineCompetence.getNomDomaineComp());

        return domaineCompetenceRepository.save(domaineCompetenceToUpdate);
    }
}


