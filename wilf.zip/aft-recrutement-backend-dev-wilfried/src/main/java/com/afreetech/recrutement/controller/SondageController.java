package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Sondage;
import com.afreetech.recrutement.service.SondageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sondages")
public class SondageController {

    private final SondageService sondageService;

    public SondageController(SondageService sondageService) {
        this.sondageService = sondageService;
    }

    @PostMapping
    public ResponseEntity<Sondage> createSondage(@RequestBody Sondage sondage) {
        Sondage savedSondage = sondageService.saveSondage(sondage);
        return new ResponseEntity<>(savedSondage, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sondage> getSondageById(@PathVariable Integer id) {
        Optional<Sondage> sondage = sondageService.getSondageById(id);
        return sondage.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<Sondage>> getAllSondages() {
        List<Sondage> sondages = sondageService.getAllSondages();
        return ResponseEntity.ok(sondages);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSondage(@PathVariable Integer id) {
        sondageService.deleteSondage(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sondage> updateSondage(@PathVariable Integer id, @RequestBody Sondage sondage) {
        try {
            Sondage updatedSondage = sondageService.updateSondage(id, sondage);
            return ResponseEntity.ok(updatedSondage);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
