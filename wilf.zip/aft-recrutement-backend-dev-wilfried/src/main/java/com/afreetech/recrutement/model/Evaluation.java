package com.afreetech.recrutement.model;

import com.afreetech.recrutement.model.users.User;
import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "rct_evaluation")
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_evaluation")
    private Long idEvaluation;

    @Column(name = "titre", nullable = false)
    private String titre;

    @Column(name = "date_evaluation", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Timestamp dateEvaluation;

    @Column(name = "decision_evaluation", nullable = false)
    private Integer decisionEvaluation;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_user", nullable = false)
    private User user;

    @OneToMany (mappedBy = "evaluation", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CritereEvalNote> critereEvalNoteList = new ArrayList<>();

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_postulant", nullable = false)
    private Postulant postulant;



    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Long getIdEvaluation() {
        return idEvaluation;
    }

    public void setIdEvaluation(Long idEvaluation) {
        this.idEvaluation = idEvaluation;
    }

    public Timestamp getDateEvaluation() {
        return dateEvaluation;
    }

    public void setDateEvaluation(Timestamp dateEvaluation) {
        this.dateEvaluation = dateEvaluation;
    }

    public Integer getDecisionEvaluation() {
        return decisionEvaluation;
    }

    public void setDecisionEvaluation(Integer decisionEvaluation) {
        this.decisionEvaluation = decisionEvaluation;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Postulant getPostulant() {
        return postulant;
    }

    public void setPostulant(Postulant postulant) {
        this.postulant = postulant;
    }

    public Evaluation() {
    }
}
