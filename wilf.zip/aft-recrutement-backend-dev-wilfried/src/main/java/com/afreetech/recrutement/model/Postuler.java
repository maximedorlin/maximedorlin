package com.afreetech.recrutement.model;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "rct_postuler")
public class Postuler {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_postuler")
    private Integer idPostuler;

    @Column(name = "date_enregistrement", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date dateEnregistrement;

    @Column(name = "statut_actuel", nullable = false)
    @Enumerated(EnumType.STRING)
    private statutActuel statutActuel;

    public enum statutActuel {
        REJETER,
        EN_COUR,
        VALIDER
    }


    @OneToMany (mappedBy = "postuler", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Document> documentList;

    @ManyToOne
    @JoinColumn(name = "id_cand", nullable = false)
    private Postulant postulant;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_job")
    private Job job;


    public void setStatutActuel(com.afreetech.recrutement.model.Postuler.statutActuel statutActuel) {
        this.statutActuel = statutActuel;
    }

    public Integer getIdPostuler() {
        return idPostuler;
    }

    public void setIdPostuler(Integer idPostuler) {
        this.idPostuler = idPostuler;
    }

    public Date getDateEnregistrement() {
        return dateEnregistrement;
    }

    public void setDateEnregistrement(Date dateEnregistrement) {
        this.dateEnregistrement = dateEnregistrement;
    }

    public com.afreetech.recrutement.model.Postuler.statutActuel getStatutActuel() {
        return statutActuel;
    }

    public Postulant getPostulant() {
        return postulant;
    }

    public void setPostulant(Postulant postulant) {
        this.postulant = postulant;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public List<Document> getDocumentList() {
        return documentList;
    }

    public void setDocumentList(List<Document> documentList) {
        this.documentList = documentList;
    }

    public Postuler() {
    }
}
