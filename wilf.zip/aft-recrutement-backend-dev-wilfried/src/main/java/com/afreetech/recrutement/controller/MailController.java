package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Mail;
import com.afreetech.recrutement.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/mails")
public class MailController {

    @Autowired
    private MailService mailService;

    @GetMapping
    public ResponseEntity<List<Mail>> getAllMails() {
        List<Mail> mails = mailService.getAllMails();
        return new ResponseEntity<>(mails, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Mail> getMailById(@PathVariable Integer id) {
        Optional<Mail> mail = mailService.getMailById(id);
        return mail.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Mail> createMail(@RequestBody Mail mail) {
        Mail savedMail = mailService.saveMail(mail);
        return new ResponseEntity<>(savedMail, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Mail> updateMail(@PathVariable Integer id, @RequestBody Mail mail) {
        if (!mailService.getMailById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        mail.setIdMail(id); // Assurez-vous que l'ID est mis à jour
        Mail updatedMail = mailService.updateMail(id, mail);
        return new ResponseEntity<>(updatedMail, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMail(@PathVariable Integer id) {
        if (!mailService.getMailById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        mailService.deleteMail(id);
        return ResponseEntity.noContent().build();
    }
}
