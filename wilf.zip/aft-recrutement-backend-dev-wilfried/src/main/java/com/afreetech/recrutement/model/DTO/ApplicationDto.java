package com.afreetech.recrutement.model.DTO;

import com.afreetech.recrutement.model.QuestionResponse;
import lombok.Data;
import java.util.List;

@Data
public class ApplicationDto {
    private List<QuestionResponse> responses;
    private String cv;
    private List<String> diplomas;
    private List<String> certifications;
    private List<String> otherDocuments;

}