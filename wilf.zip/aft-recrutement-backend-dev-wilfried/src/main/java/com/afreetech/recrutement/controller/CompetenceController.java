package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Competence;
import com.afreetech.recrutement.service.CompetenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/competences")
public class CompetenceController {

    @Autowired
    private CompetenceService competenceService;

    @GetMapping
    public ResponseEntity<List<Competence>> getAllCompetences() {
        List<Competence> competences = competenceService.getAllCompetences();
        return new ResponseEntity<>(competences, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Competence> getCompetenceById(@PathVariable("id") Integer idCompetence) {
        Optional<Competence> competence = competenceService.getCompetenceById(idCompetence);
        return competence.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Competence> createCompetence(@RequestBody Competence competence) {
        Competence savedCompetence = competenceService.saveCompetence(competence);
        return new ResponseEntity<>(savedCompetence, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Competence> updateCompetence(@PathVariable("id") Integer idCompetence, @RequestBody Competence competence) {
        if (!competenceService.getCompetenceById(idCompetence).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        competence.setIdCompetence(idCompetence); // Assurez-vous que l'ID est mis à jour
        Competence updatedCompetence = competenceService.updateCompetence(idCompetence, competence);
        return new ResponseEntity<>(updatedCompetence, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCompetence(@PathVariable("id") Integer idCompetence) {
        if (!competenceService.getCompetenceById(idCompetence).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        competenceService.deleteCompetence(idCompetence);
        return ResponseEntity.noContent().build();
    }
}
