package com.afreetech.recrutement.repository;

import com.afreetech.recrutement.model.Postulant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PostulantRepository extends JpaRepository<Postulant, Integer> {
    // Vous pouvez ajouter des méthodes de requête personnalisées ici si nécessaire
}
