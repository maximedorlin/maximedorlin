package com.afreetech.recrutement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "aft_sondage")
public class Sondage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sondage")
    private Integer idSondage;

    @Column(name = "titre", nullable = false, length = 100)
    private String titre;

    @Column(name = "question", nullable = false)
    private String quetion;

    // @Column(name = "reponce", nullable = false)
    // private String reponce;

    @Enumerated(EnumType.STRING)
    @Column(name = "reponses", nullable = false)
    private reponce reponce;

    public enum reponce {
        reponce1,
        reponce2,
        reponce3
    }


    public Integer getIdSondage() {
        return idSondage;
    }

    public Sondage() {
    }

    public void setIdSondage(Integer idSondage) {
        this.idSondage = idSondage;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getQuetion() {
        return quetion;
    }

    public void setQuetion(String quetion) {
        this.quetion = quetion;
    }

    public com.afreetech.recrutement.model.Sondage.reponce getReponce() {
        return reponce;
    }

    public void setReponce(com.afreetech.recrutement.model.Sondage.reponce reponce) {
        this.reponce = reponce;
    }
}
