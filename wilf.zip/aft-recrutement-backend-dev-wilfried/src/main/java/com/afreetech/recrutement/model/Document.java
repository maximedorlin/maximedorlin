package com.afreetech.recrutement.model;

import jakarta.persistence.*;

@Entity
@Table(name = "rct_document")
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_doc")
    private Integer idDocument;

    @Column(name = "annee_obtention", nullable = false)
    private Integer anneeObtention;

    @Column(name = "titre_doc", nullable = false, length = 200)
    private String titreDoc;

    @Column(name = "etablissement_obtention", nullable = false, length = 200)
    private String etablissementObtention;

    @Column(name = "mention", nullable = false)
    private Integer mention;

    @Column(name = "type", nullable = false)
    private Integer type;

    @Column(name = "doc_courant", nullable = false)
    private Boolean docCourant;


    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_postuler", nullable = false)
    private Postuler postuler;


    public Integer getIdDocument() {
        return idDocument;
    }

    public void setIdDocument(Integer idDocument) {
        this.idDocument = idDocument;
    }

    public Integer getAnneeObtention() {
        return anneeObtention;
    }

    public void setAnneeObtention(Integer anneeObtention) {
        this.anneeObtention = anneeObtention;
    }

    public String getTitreDoc() {
        return titreDoc;
    }

    public void setTitreDoc(String titreDoc) {
        this.titreDoc = titreDoc;
    }

    public String getEtablissementObtention() {
        return etablissementObtention;
    }

    public void setEtablissementObtention(String etablissementObtention) {
        this.etablissementObtention = etablissementObtention;
    }

    public Integer getMention() {
        return mention;
    }

    public void setMention(Integer mention) {
        this.mention = mention;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Boolean getDocCourant() {
        return docCourant;
    }

    public void setDocCourant(Boolean docCourant) {
        this.docCourant = docCourant;
    }

    public Postuler getPostuler() {
        return postuler;
    }

    public void setPostulant(Postuler postulant) {
        this.postuler = postuler;
    }

    public Document() {
    }
}
