package com.afreetech.recrutement.controller;



import com.afreetech.recrutement.model.Postulant;
import com.afreetech.recrutement.service.PostulantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/postulants")
public class PostulantController {

    @Autowired
    private PostulantService postulantService;

    @PostMapping
    public ResponseEntity<Postulant> createPostulant(@RequestBody Postulant postulant) {
        Postulant createdPostulant = postulantService.savePostulant(postulant);
        return new ResponseEntity<>(createdPostulant, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Postulant> getPostulantById(@PathVariable Integer id) {
        Optional<Postulant> postulant = postulantService.getPostulantById(id);
        return postulant.map(ResponseEntity::ok)
                        .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<Postulant>> getAllPostulants() {
        List<Postulant> postulants = postulantService.getAllPostulants();
        return ResponseEntity.ok(postulants);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Postulant> updatePostulant(@PathVariable Integer id, @RequestBody Postulant postulant) {
        Postulant updatedPostulant = postulantService.updatePostulant(id, postulant);
        if (updatedPostulant != null) {
            return ResponseEntity.ok(updatedPostulant);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePostulant(@PathVariable Integer id) {
        postulantService.deletePostulant(id);
        return ResponseEntity.noContent().build();
    }
}
