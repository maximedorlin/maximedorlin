package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Document;

import java.util.List;
import java.util.Optional;

public interface DocumentService {

    Document saveDocument(Document document);

    Optional<Document> getDocumentById(Integer idDocument);

    List<Document> getAllDocuments();

    void deleteDocument(Integer idDocument);

    Document updateDocument(Integer idDocument, Document document);
}
