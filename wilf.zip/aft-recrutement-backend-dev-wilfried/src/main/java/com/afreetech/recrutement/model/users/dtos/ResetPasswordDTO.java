package com.afreetech.recrutement.model.users.dtos;

public record ResetPasswordDTO(String newPassword) {
}
