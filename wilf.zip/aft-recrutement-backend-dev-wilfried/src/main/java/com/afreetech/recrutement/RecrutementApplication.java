package com.afreetech.recrutement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecrutementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecrutementApplication.class, args);
	}

}
