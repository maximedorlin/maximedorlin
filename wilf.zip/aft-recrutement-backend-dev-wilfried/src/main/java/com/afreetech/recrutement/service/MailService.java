package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Mail;

import java.util.List;
import java.util.Optional;

public interface MailService {

    Mail saveMail(Mail mail);

    Optional<Mail> getMailById(Integer idMail);

    List<Mail> getAllMails();

    void deleteMail(Integer idMail);

    Mail updateMail(Integer idMail, Mail mail);
}
