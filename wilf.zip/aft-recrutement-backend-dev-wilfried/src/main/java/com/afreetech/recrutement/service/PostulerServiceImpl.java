package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Postuler;
import com.afreetech.recrutement.repository.PostulerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PostulerServiceImpl implements PostulerService {

    @Autowired
    private PostulerRepository postulerRepository;

    @Override
    public Postuler savePostuler(Postuler postuler) {
        return postulerRepository.save(postuler);
    }

    @Override
    public Optional<Postuler> getPostulerById(Integer idPostuler) {
        return postulerRepository.findById(idPostuler);
    }

    @Override
    public List<Postuler> getAllPostulers() {
        return postulerRepository.findAll();
    }

    @Override
    public void deletePostuler(Integer idPostuler) {
        postulerRepository.deleteById(idPostuler);
    }

    @Override
    public Postuler updatePostuler(Integer idPostuler, Postuler postuler) {
        // Trouver l'entité existante par ID
        Postuler postulerToUpdate = postulerRepository.findById(idPostuler)
                .orElseThrow(() -> new RuntimeException("Postuler not found with id " + idPostuler));

        // Mettre à jour les attributs de l'entité trouvée
        postulerToUpdate.setDateEnregistrement(postuler.getDateEnregistrement());
        postulerToUpdate.setStatutActuel(postuler.getStatutActuel());
        postulerToUpdate.setPostulant(postuler.getPostulant());
        postulerToUpdate.setJob(postuler.getJob());
        postulerToUpdate.setDocumentList(postuler.getDocumentList());

        // Sauvegarder les modifications
        return postulerRepository.save(postulerToUpdate);
    }
}
