package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.CritereEvalNote;
import java.util.List;
import java.util.Optional;

public interface CritereEvalNoteService {

    CritereEvalNote saveCritereEvalNote(CritereEvalNote critereEvalNote);

    Optional<CritereEvalNote> getCritereEvalNoteById(Long idCritereEvalNote);

    List<CritereEvalNote> getAllCritereEvalNotes();

    void deleteCritereEvalNote(Long idCritereEvalNote);

    CritereEvalNote updateCritereEvalNote(Long idCritereEvalNote, CritereEvalNote critereEvalNote);
}
