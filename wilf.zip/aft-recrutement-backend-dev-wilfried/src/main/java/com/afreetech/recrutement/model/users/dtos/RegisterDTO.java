package com.afreetech.recrutement.model.users.dtos;


import com.afreetech.recrutement.model.users.UserRole;

public record RegisterDTO(String name, String email, String password, String confirmPassword, String phoneNumber, UserRole role) {
}
