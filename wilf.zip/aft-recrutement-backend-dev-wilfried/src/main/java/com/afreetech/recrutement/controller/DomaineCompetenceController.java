package com.afreetech.recrutement.controller;

import com.afreetech.recrutement.model.Competence;
import com.afreetech.recrutement.model.DomaineCompetence;
import com.afreetech.recrutement.service.CompetenceService;
import com.afreetech.recrutement.service.DomaineCompetenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/domaine-competences")
public class DomaineCompetenceController {

    @Autowired
    private DomaineCompetenceService domaineCompetenceService;
    private CompetenceService competenceService;

    // Récupérer tous les domaines de compétence
    @GetMapping
    public ResponseEntity<List<DomaineCompetence>> getAllDomaineCompetences() {
        List<DomaineCompetence> domaineCompetences = domaineCompetenceService.getAllDomaineCompetences();
        return new ResponseEntity<>(domaineCompetences, HttpStatus.OK);
    }

    // Récupérer un domaine de compétence par ID
    @GetMapping("/{id}")
    public ResponseEntity<DomaineCompetence> getDomaineCompetenceById(@PathVariable Integer id) {
        Optional<DomaineCompetence> domaineCompetence = domaineCompetenceService.getDomaineCompetenceById(id);
        return domaineCompetence.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }


//    @PostMapping
//    public ResponseEntity<DomaineCompetence> createDomaineCompetence(@RequestBody DomaineCompetence domaineCompetence) {
//        DomaineCompetence savedDomaineCompetence = domaineCompetenceService.saveDomaineCompetence(domaineCompetence);
//        return new ResponseEntity<>(savedDomaineCompetence, HttpStatus.CREATED);
//    }

//    @PostMapping("/batch")
//    public ResponseEntity<List<DomaineCompetence>> createDomaines(@RequestBody List<DomaineCompetence> domaineCompetence) {
//        List<DomaineCompetence> savedDomaines = domaineCompetenceService.saveAll(domaineCompetence);
//        return new ResponseEntity<>(savedDomaines, HttpStatus.CREATED);
//    }

    @PostMapping("/batch")
    public ResponseEntity<DomaineCompetence> createDomaineCompetence(@RequestBody DomaineCompetence domaineCompetence) {
        if (domaineCompetence.getCompetencesList() == null) {
//            return ResponseEntity.badRequest().body("pas competences.");
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }


        Optional<Competence> competence = competenceService.getCompetenceById(domaineCompetence.getIdDomaineComp());
        domaineCompetence.setCompetencesList(competence);
        DomaineCompetence domaineCompetence1 = domaineCompetenceService.saveDomaineCompetence(domaineCompetence);
//        return ResponseEntity.ok(domaineCompetence1, HttpStatus.CREATED);
        return new ResponseEntity<>(domaineCompetence1, HttpStatus.CREATED);
    }

    // Mettre à jour un domaine de compétence existant
    @PutMapping("/{id}")
    public ResponseEntity<DomaineCompetence> updateDomaineCompetence(@PathVariable Integer id, @RequestBody DomaineCompetence domaineCompetence) {
        if (!domaineCompetenceService.getDomaineCompetenceById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        domaineCompetence.setIdDomaineComp(id); // Assurez-vous que l'ID est mis à jour
        DomaineCompetence updatedDomaineCompetence = domaineCompetenceService.updateDomaineCompetence(id, domaineCompetence);
        return new ResponseEntity<>(updatedDomaineCompetence, HttpStatus.OK);
    }

    // Supprimer un domaine de compétence par ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDomaineCompetence(@PathVariable Integer id) {
        if (!domaineCompetenceService.getDomaineCompetenceById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        domaineCompetenceService.deleteDomaineCompetence(id);
        return ResponseEntity.noContent().build();
    }
}