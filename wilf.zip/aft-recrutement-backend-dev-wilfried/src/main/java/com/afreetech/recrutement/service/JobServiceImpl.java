package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Job;
import com.afreetech.recrutement.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private JobRepository jobRepository;

    @Override
    public Job saveJob(Job job) {
        return jobRepository.save(job);
    }

    @Override
    public Optional<Job> getJobById(Integer idJob) {
        return jobRepository.findById(idJob);
    }

    @Override
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    @Override
    public void deleteJob(Integer idJob) {
        jobRepository.deleteById(idJob);
    }

    @Override
    public Job updateJob(Integer idJob, Job job) {
        Job jobToUpdate = jobRepository.findById(idJob)
                .orElseThrow(() -> new RuntimeException("Job not found with id " + idJob));

        jobToUpdate.setTitreJob(job.getTitreJob());
        jobToUpdate.setDatePost(job.getDatePost());
        jobToUpdate.setFichierAnnonce(job.getFichierAnnonce());
        jobToUpdate.setAnnonce(job.getAnnonce());
        jobToUpdate.setStatut(job.getStatut());
        jobToUpdate.setTypeContrat(job.getTypeContrat());
        jobToUpdate.setDateLimite(job.getdateLimite());
        jobToUpdate.setPostulerList(job.getPostulerList());

        return jobRepository.save(jobToUpdate);
    }
}
