package com.afreetech.recrutement.repository;

import com.afreetech.recrutement.model.Application;
import com.afreetech.recrutement.model.JobOffer;
import com.afreetech.recrutement.model.users.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByUser(User user);
    boolean existsByUserAndJobOffer(User user, JobOffer jobOffer);
}
