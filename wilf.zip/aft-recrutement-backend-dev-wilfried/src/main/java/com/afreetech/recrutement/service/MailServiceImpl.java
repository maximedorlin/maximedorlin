package com.afreetech.recrutement.service;

import com.afreetech.recrutement.model.Mail;
import com.afreetech.recrutement.repository.MailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MailServiceImpl implements MailService {

    @Autowired
    private MailRepository mailRepository;

    @Override
    public Mail saveMail(Mail mail) {
        return mailRepository.save(mail);
    }

    @Override
    public Optional<Mail> getMailById(Integer idMail) {
        return mailRepository.findById(idMail);
    }

    @Override
    public List<Mail> getAllMails() {
        return mailRepository.findAll();
    }

    @Override
    public void deleteMail(Integer idMail) {
        mailRepository.deleteById(idMail);
    }

    @Override
    public Mail updateMail(Integer idMail, Mail mail) {
        Mail mailToUpdate = mailRepository.findById(idMail)
                .orElseThrow(() -> new RuntimeException("Mail not found with id " + idMail));

        mailToUpdate.setTypeMail(mail.getTypeMail());
        mailToUpdate.setDescriptionMail(mail.getDescriptionMail());
        mailToUpdate.setContenuMail(mail.getContenuMail());

        return mailRepository.save(mailToUpdate);
    }
}
