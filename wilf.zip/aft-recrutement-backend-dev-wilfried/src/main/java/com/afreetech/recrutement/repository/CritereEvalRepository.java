package com.afreetech.recrutement.repository;

import com.afreetech.recrutement.model.CritereEval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CritereEvalRepository extends JpaRepository<CritereEval, Integer> {
}
